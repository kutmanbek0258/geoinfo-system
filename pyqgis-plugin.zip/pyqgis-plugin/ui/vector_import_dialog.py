import os
import zipfile
import tempfile
import shutil
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QLineEdit, 
    QProgressBar, QMessageBox, QApplication,
    QComboBox
)
from qgis.core import QgsMessageLog, Qgis, QgsProject, QgsVectorLayer

class VectorImportDialog(QDialog):
    def __init__(self, api_client, project_id, folder_id=None, parent=None):
        super().__init__(parent)
        self.api = api_client
        self.project_id = project_id
        self.folder_id = folder_id
        self.temp_zip = None
        
        self.setWindowTitle("Импорт Shapefile из QGIS")
        self.setMinimumWidth(450)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        self.info_label = QLabel(
            "Выберите векторный слой (Shapefile) из текущего проекта QGIS.\n"
            "Плагин автоматически найдет все компоненты (.shp, .dbf, .shx, .prj) и упакует их в ZIP для загрузки."
        )
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("color: #666; margin-bottom: 10px;")
        layout.addWidget(self.info_label)

        # Layer selection
        layout.addWidget(QLabel("Выберите слой:"))
        self.layer_combo = QComboBox()
        layout.addWidget(self.layer_combo)

        # Name field
        layout.addWidget(QLabel("Название импорта в системе:"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Например: Границы области")
        layout.addWidget(self.name_edit)

        self.refresh_layers()
        
        self.layer_combo.currentIndexChanged.connect(self.on_layer_selected)

        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        self.progress_label = QLabel("")
        self.progress_label.setVisible(False)
        layout.addWidget(self.progress_label)

        # Actions
        actions = QHBoxLayout()
        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)
        self.import_btn = QPushButton("Упаковать и импортировать")
        self.import_btn.setStyleSheet("background-color: #2ecc71; color: white; font-weight: bold; padding: 8px;")
        self.import_btn.clicked.connect(self.start_import)
        
        actions.addStretch()
        actions.addWidget(self.cancel_btn)
        actions.addWidget(self.import_btn)
        layout.addLayout(actions)

    def refresh_layers(self):
        self.layer_combo.clear()
        layers = QgsProject.instance().mapLayers().values()
        for layer in layers:
            if isinstance(layer, QgsVectorLayer) and layer.dataProvider().name() == 'ogr':
                source = layer.source()
                # Basic check for .shp
                if source.lower().split('|')[0].endswith('.shp'):
                    self.layer_combo.addItem(layer.name(), layer.id())
        
        if self.layer_combo.count() == 0:
            self.layer_combo.addItem("Нет доступных Shapefile слоев", None)
            self.import_btn.setEnabled(False)
        else:
            self.on_layer_selected()

    def on_layer_selected(self):
        layer_id = self.layer_combo.currentData()
        if not layer_id: return
        
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer:
            self.name_edit.setText(layer.name())

    def update_progress(self, current, total):
        if total > 0:
            percent = int((current / total) * 100)
            self.progress_bar.setValue(percent)
            QApplication.processEvents()

    def get_shapefile_files(self, shp_path):
        """Finds all files belonging to the shapefile (.dbf, .shx, .prj, .cpg, etc)."""
        # Handle cases where source might have pipe separators for encoding/etc
        clean_shp_path = shp_path.split('|')[0]
        base_path = os.path.splitext(clean_shp_path)[0]
        directory = os.path.dirname(clean_shp_path)
        base_name = os.path.basename(base_path)
        
        related_files = []
        if os.path.exists(clean_shp_path):
            for f in os.listdir(directory):
                if os.path.splitext(f)[0] == base_name:
                    related_files.append(os.path.join(directory, f))
        return related_files

    def create_zip(self, files):
        """Creates a temporary zip file containing the listed files."""
        temp_dir = tempfile.mkdtemp()
        zip_name = "upload.zip"
        zip_path = os.path.join(temp_dir, zip_name)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for f in files:
                zipf.write(f, os.path.basename(f))
        
        return zip_path

    def start_import(self):
        layer_id = self.layer_combo.currentData()
        if not layer_id:
            QMessageBox.warning(self, "Ошибка", "Выберите корректный слой")
            return

        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Ошибка", "Введите название импорта")
            return

        layer = QgsProject.instance().mapLayer(layer_id)
        if not layer: return

        shp_path = layer.source().split('|')[0]
        if not os.path.exists(shp_path):
            QMessageBox.critical(self, "Ошибка", f"Файл не найден на диске: {shp_path}")
            return

        try:
            self.set_loading(True)
            
            # 1. Prepare ZIP
            self.progress_label.setText("Поиск файлов и упаковка в ZIP...")
            files = self.get_shapefile_files(shp_path)
            if not any(f.lower().endswith('.dbf') for f in files) or not any(f.lower().endswith('.shx') for f in files):
                raise Exception("Не найдены обязательные компоненты (.dbf или .shx)")
            
            self.temp_zip = self.create_zip(files)
            zip_size = os.path.getsize(self.temp_zip)
            
            # 2. Get Presigned URL
            self.progress_label.setText("Подготовка импорта на сервере...")
            filename = f"{name}.zip"
            init_res = self.api.init_vector_import(self.project_id, self.folder_id, name, filename)
            
            if not init_res or 'url' not in init_res:
                raise Exception("Не удалось получить URL для загрузки")

            # 3. Upload
            self.progress_label.setText("Загрузка ZIP архива...")
            success = self.api.upload_file(
                init_res['url'], 
                self.temp_zip, 
                progress_callback=self.update_progress
            )
            
            if not success:
                raise Exception("Ошибка при передаче файла в хранилище")

            # 4. Confirm
            self.progress_label.setText("Запуск обработки...")
            confirm_res = self.api.confirm_raster_upload(
                name, 
                init_res['objectKey'], 
                zip_size, 
                task_type="SHAPEFILE_TO_GEOJSON"
            )

            if confirm_res:
                QMessageBox.information(self, "Успех", 
                    "Слой успешно упакован и отправлен на сервер.\n"
                    "Объекты появятся в проекте через несколько секунд.")
                self.accept()
            else:
                raise Exception("Не удалось подтвердить импорт")

        except Exception as e:
            QgsMessageLog.logMessage(f"GeoInfoSystem: Layer import failed: {str(e)}", "GeoInfoSystem", Qgis.Critical)
            QMessageBox.critical(self, "Ошибка импорта", str(e))
            self.set_loading(False)
        finally:
            # Cleanup temp zip
            if self.temp_zip and os.path.exists(self.temp_zip):
                shutil.rmtree(os.path.dirname(self.temp_zip), ignore_errors=True)
                self.temp_zip = None

    def set_loading(self, loading):
        self.import_btn.setEnabled(not loading)
        self.cancel_btn.setEnabled(not loading)
        self.layer_combo.setEnabled(not loading)
        self.name_edit.setEnabled(not loading)
        self.progress_bar.setVisible(loading)
        self.progress_label.setVisible(loading)
        if loading:
            self.progress_bar.setValue(0)
